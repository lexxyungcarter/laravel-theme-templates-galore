<b>Warning!</b> It`s only copy of <a href="http://wrapbootstrap.com/preview/WB0B30DGR">ace demo-template</a> from wrapbootstrap.
Repo contains minified ace js/css files.
You can read more about the license <a href="https://wrapbootstrap.com/theme/ace-responsive-admin-template-WB0B30DGR">here</a>.

<h3>I`m not developer of this theme.</h3>

<h2>Twitter bootstrap 3 admin template</h2>

see example http://ace.jeka.by/


Try:
- git clone git@github.com:bopoda/ace.git
- open ace/index.html in your desktop or mobile browser


Простой и многофункциональный Twitter bootstrap 3 шаблон для админки. Responsive дизайн.

Browsers:
- Internet Explorer 10
- Internet Explorer 11
- Internet Explorer 8
- Internet Explorer 9
- Latest Chrome
- Latest Firefox
- Latest Opera
- Latest Safari
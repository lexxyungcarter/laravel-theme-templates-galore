<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use SEO;

class HomeController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('accesstoken');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $path = resource_path('views/templates');
        $results = scandir($path);
        $templates = collect();

        foreach ($results as $result) {
            if ($result === '.' or $result === '..') continue;

            if (is_dir($path . '/' . $result)) {
                //code to use if directory
                $templates->push($result);
            }
        }

        return view('welcome')
        ->with([
            'title' => 'Laravel Themes Galore',
            'page' => 'Home',
            'templates' => $templates,
        ]);
    }

    /**
     * view pages dynamiclly in the system
     * 
     * @param string $page
     * @return view
     */
    public function show($theme, $page)
    {
        $view = 'templates.' . $theme . '.' . $page;

        // set SEO
        SEO::setTitle(ucwords($page) . ' - ' . ucwords($theme) . ' Template | AceLords Themes Galore');
        SEO::setDescription(ucwords($page) . ' page for the ' . ucwords($theme) . ' Template | AceLords Themes Galore');
        SEO::opengraph()->setUrl(request()->url());
        SEO::setCanonical(request()->url());
        SEO::opengraph()->addProperty('type', 'page');
        SEO::opengraph()->addProperty('image', request()->root() . '/templates/' . $theme . '/screenshot.jpg');
        // SEO::twitter()->setSite('@acelords');

        
        return view($view)
        ->with([
            'theme' => $theme,
            'title' => ucwords($page),
            'page' => $page,
            'page_desc' => $page . ' Page',
        ]);
    }
}

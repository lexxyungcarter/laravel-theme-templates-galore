@extends('templates.' . $theme . '.layouts.main')

@section('styles')
    
@endsection

@section('content')
    
@endsection
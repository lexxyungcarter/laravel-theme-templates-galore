<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="initial-scale=1.0" />
	<meta name="format-detection" content="telephone=no" />
	<title></title>
	<style type="text/css">
		body {
			width: 100%;
			margin: 0;
			padding: 0;
			-webkit-font-smoothing: antialiased;
		}

		@media only screen and (max-width: 600px) {
			table[class="table-row"] {
				float: none !important;
				width: 98% !important;
				padding-left: 20px !important;
				padding-right: 20px !important;
			}
			table[class="table-row-fixed"] {
				float: none !important;
				width: 98% !important;
			}
			table[class="table-col"],
			table[class="table-col-border"] {
				float: none !important;
				width: 100% !important;
				padding-left: 0 !important;
				padding-right: 0 !important;
				table-layout: fixed;
			}
			td[class="table-col-td"] {
				width: 100% !important;
			}
			table[class="table-col-border"]+table[class="table-col-border"] {
				padding-top: 12px;
				margin-top: 12px;
				border-top: 1px solid #E8E8E8;
			}
			table[class="table-col"]+table[class="table-col"] {
				margin-top: 15px;
			}
			td[class="table-row-td"] {
				padding-left: 0 !important;
				padding-right: 0 !important;
			}
			table[class="navbar-row"],
			td[class="navbar-row-td"] {
				width: 100% !important;
			}
			img {
				max-width: 100% !important;
				display: inline !important;
			}
			img[class="pull-right"] {
				float: right;
				margin-left: 11px;
				max-width: 125px !important;
				padding-bottom: 0 !important;
			}
			img[class="pull-left"] {
				float: left;
				margin-right: 11px;
				max-width: 125px !important;
				padding-bottom: 0 !important;
			}
			table[class="table-space"],
			table[class="header-row"] {
				float: none !important;
				width: 98% !important;
			}
			td[class="header-row-td"] {
				width: 100% !important;
			}
		}

		@media only screen and (max-width: 480px) {
			table[class="table-row"] {
				padding-left: 16px !important;
				padding-right: 16px !important;
			}
		}

		@media only screen and (max-width: 320px) {
			table[class="table-row"] {
				padding-left: 12px !important;
				padding-right: 12px !important;
			}
		}

		@media only screen and (max-width: 608px) {
			td[class="table-td-wrap"] {
				width: 100% !important;
			}
		}
	</style>
</head>

<body style="font-family: Arial, sans-serif; font-size:13px; color: #444444; min-height: 200px;" bgcolor="#E4E6E9" leftmargin="0"
    topmargin="0" marginheight="0" marginwidth="0">
	<table width="100%" height="100%" bgcolor="#E4E6E9" cellspacing="0" cellpadding="0" border="0">
		<tr>
			<td width="100%" align="center" valign="top" bgcolor="#E4E6E9" style="background-color:#E4E6E9; min-height: 200px;">
				<table>
					<tr>
						<td class="table-td-wrap" align="center" width="608">
							<div style="font-family: Arial, sans-serif; line-height: 32px; color: #444444; font-size: 13px;">
								Can't read this email?
								<a href="#" style="color: #478fca; text-decoration: none; font-size: 14px; background-color: transparent;">
									View it Online &rarr;
								</a>
							</div>

							<table class="table-row" style="table-layout: auto; padding-right: 24px; padding-left: 24px; width: 600px; background-color: #ffffff;"
							    bgcolor="#FFFFFF" width="600" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr height="55px" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; height: 55px;">
										<td class="table-row-td" style="height: 55px; padding-right: 16px; font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; vertical-align: middle;"
										    valign="middle" align="left">
											<a href="#" style="color: #428bca; text-decoration: none; padding: 0px; font-size: 18px; line-height: 20px; height: 50px; background-color: transparent;">
												Ace Newsletter
											</a>
										</td>

										<td class="table-row-td" style="height: 55px; font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; text-align: right; vertical-align: middle;"
										    align="right" valign="middle">
											<a href="#" style="color: #428bca; text-decoration: none; font-size: 15px; background-color: transparent;">
												About
											</a>
											&nbsp;
											<a href="#" style="color: #428bca; text-decoration: none; font-size: 15px; background-color: transparent;">
												Contact
											</a>
										</td>
									</tr>
								</tbody>
							</table>


							<table class="table-space" height="6" style="height: 6px; font-size: 0px; line-height: 0; width: 600px; background-color: #e4e6e9;"
							    width="600" bgcolor="#E4E6E9" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="6" style="height: 6px; width: 600px; background-color: #e4e6e9;"
										    width="600" bgcolor="#E4E6E9" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="16" style="height: 16px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="16" style="height: 16px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>

							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 24px; padding-right: 24px;"
										    valign="top" align="left">
											<table class="table-col" align="left" width="552" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="552" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<div style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; text-align: center;">
																<img src="/templates/ace/assets/images/placeholder/550x280.png" style="border: 0px none #444444; vertical-align: middle; display: block; padding-bottom: 9px;"
																    hspace="0" vspace="0" border="0">
															</div>
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>

							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 36px; padding-right: 36px;"
										    valign="top" align="left">
											<table class="table-col" align="left" width="528" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="528" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<table class="header-row" width="528" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
																<tbody>
																	<tr>
																		<td class="header-row-td" width="528" style="font-size: 28px; margin: 0px; font-family: Arial, sans-serif; font-weight: normal; line-height: 19px; color: #478fca; padding-bottom: 10px; padding-top: 15px;"
																		    valign="top" align="left">Hi, Susan Calvin</td>
																	</tr>
																</tbody>
															</table>
															<table class="header-row" width="528" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
																<tbody>
																	<tr>
																		<td class="header-row-td" width="528" style="font-family: Arial, sans-serif; font-weight: normal; line-height: 19px; color: #444444; margin: 0px; font-size: 18px; padding-bottom: 8px; padding-top: 10px;"
																		    valign="top" align="left">Phasellus dictum sapien a neque luctus cursus. Pellentesque sem dolor, fringilla et pharetra vitae.</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>


							<table class="table-space" height="12" style="height: 12px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="12" style="height: 12px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 36px; padding-right: 36px;"
										    valign="top" align="left">
											<table class="table-col" align="left" width="528" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="528" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<table width="100%" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
																<tbody>
																	<tr>
																		<td width="100%" bgcolor="#d9edf7" style="font-family: Arial, sans-serif; line-height: 19px; color: #31708f; font-size: 14px; font-weight: normal; padding: 15px; border: 1px solid #bce8f1; background-color: #d9edf7;"
																		    valign="top" align="left">
																			You can also use Zurb's responsive email templates built on Ink.
																			<br>
																			<a href="http://zurb.com/ink/templates.php" style="color: #428bca; text-decoration: none; background-color: transparent;">Click here to see them</a>
																		</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="24" style="height: 24px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="24" style="height: 24px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>

							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 36px; padding-right: 36px;"
										    valign="top" align="left">
											<table class="table-col" align="left" width="528" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="528" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; width: 528px;"
														    valign="top" align="left">
															<table class="header-row" width="528" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
																<tbody>
																	<tr>
																		<td class="header-row-td" width="528" style="font-family: Arial, sans-serif; font-weight: normal; line-height: 19px; color: #6397bf; margin: 0px; font-size: 18px; padding-bottom: 8px; padding-top: 10px;"
																		    valign="top" align="left">Our latest products</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>

							<table class="table-space" height="6" style="height: 6px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="6" style="height: 6px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 36px; padding-right: 36px;"
										    valign="top" align="left">
											<table class="table-col-border" align="left" width="181" style="padding-right: 16px; table-layout: fixed;" cellspacing="0"
											    cellpadding="0" border="0">
												<tbody>
													<tr>
														<td class="table-col-td" width="165" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<img class="pull-left" src="/templates/ace/assets/images/placeholder/165x90.png" style="border: 0px none #444444; vertical-align: middle; display: block; padding-bottom: 9px;"
															    hspace="0" vspace="0" border="0">
															<span style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px;">
																<a href="#" style="color: #5b7a91; text-decoration: none; background-color: transparent;">
																	<b>Aenean sed tellus</b>
																</a>
																<br> Pellentesque non lacinia mi
															</span>
														</td>
													</tr>
												</tbody>
											</table>

											<table class="table-col-border" align="left" width="181" style="padding-right: 16px; table-layout: fixed;" cellspacing="0"
											    cellpadding="0" border="0">
												<tbody>
													<tr>
														<td class="table-col-td" width="165" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<img class="pull-left" src="/templates/ace/assets/images/placeholder/165x90.png" style="border: 0px none #444444; vertical-align: middle; display: block; padding-bottom: 9px;"
															    hspace="0" vspace="0" border="0">
															<span style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px;">
																<a href="#" style="color: #5b7a91; text-decoration: none; background-color: transparent;">
																	<b>Nullam massa sapien</b>
																</a>
																<br> Fusce sit amet libero
															</span>
														</td>
													</tr>
												</tbody>
											</table>

											<table class="table-col-border" align="left" width="165" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="165" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<img class="pull-left" src="/templates/ace/assets/images/placeholder/165x90.png" style="border: 0px none #444444; vertical-align: middle; display: block; padding-bottom: 9px;"
															    hspace="0" vspace="0" border="0">
															<span style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px;">
																<a href="#" style="color: #5b7a91; text-decoration: none; background-color: transparent;">
																	<b>Convallis eget</b>
																</a>
																<br> Cras nunc sapien interdum
															</span>
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>

							<table class="table-space" height="6" style="height: 6px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="6" style="height: 6px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="32" style="height: 32px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="32" style="height: 32px; width: 600px; padding-left: 18px; padding-right: 18px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="center">&nbsp;
											<table bgcolor="#E8E8E8" height="0" width="100%" cellspacing="0" cellpadding="0" border="0">
												<tbody>
													<tr>
														<td bgcolor="#E8E8E8" height="1" width="100%" style="height: 1px; font-size:0;" valign="top" align="left">&nbsp;</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>

							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 36px; padding-right: 36px;"
										    valign="top" align="left">
											<table class="table-col" align="left" width="528" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="528" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<span style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 14px;">
																Phasellus dictum sapien a neque luctus cursus. Pellentesque sem dolor, fringilla et pharetra vitae.
															</span>

															<table class="table-space" height="12" style="height: 12px; font-size: 0px; line-height: 0; width: 528px; background-color: #ffffff;"
															    width="528" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
																<tbody>
																	<tr>
																		<td class="table-space-td" valign="middle" height="12" style="height: 12px; width: 528px; background-color: #ffffff;"
																		    width="528" bgcolor="#FFFFFF" align="left">&nbsp;</td>
																	</tr>
																</tbody>
															</table>
															Sed iaculis pulvinar ligula, ornare fringilla ante viverra et. In hac habitasse platea dictumst. Donec vel orci mi, eu congue
															justo.
															<table class="table-space" height="16" style="height: 16px; font-size: 0px; line-height: 0; width: 528px; background-color: #ffffff;"
															    width="528" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
																<tbody>
																	<tr>
																		<td class="table-space-td" valign="middle" height="16" style="height: 16px; width: 528px; background-color: #ffffff;"
																		    width="528" bgcolor="#FFFFFF" align="left">&nbsp;</td>
																	</tr>
																</tbody>
															</table>

															<i style="color: #a94442;">Integer eget odio est, eget malesuada lorem:</i>
															<ul style="margin: 0px; padding: 5px 0px 5px 25px;">
																<li style="margin: 0px; padding-top: 4px; padding-bottom: 4px;">
																	Aenean sed tellus dui, vitae viverra risus
																</li>
																<li style="margin: 0px; padding-top: 4px; padding-bottom: 4px;">
																	Nullam massa sapien, pulvinar eleifend fringilla id
																</li>
																<li style="margin: 0px; padding-top: 4px; padding-bottom: 0px;">
																	Convallis eget nisi mauris a sagittis dui
																</li>
															</ul>

															<table class="table-space" height="16" style="height: 16px; font-size: 0px; line-height: 0; width: 528px; background-color: #ffffff;"
															    width="528" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
																<tbody>
																	<tr>
																		<td class="table-space-td" valign="middle" height="16" style="height: 16px; width: 528px; background-color: #ffffff;"
																		    width="528" bgcolor="#FFFFFF" align="left">&nbsp;</td>
																	</tr>
																</tbody>
															</table>
															Pellentesque non lacinia mi. Fusce sit amet libero sit amet erat venenatis sollicitudin vitae vel eros. Cras nunc sapien,
															interdum sit amet porttitor ut, congue quis urna.
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>


							<table class="table-space" height="16" style="height: 16px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="16" style="height: 16px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="12" style="height: 12px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="12" style="height: 12px; width: 600px; padding-left: 18px; padding-right: 18px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="center">&nbsp;
											<table bgcolor="#E8E8E8" height="0" width="100%" cellspacing="0" cellpadding="0" border="0">
												<tbody>
													<tr>
														<td bgcolor="#E8E8E8" height="1" width="100%" style="height: 1px; font-size:0;" valign="top" align="left">&nbsp;</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="12" style="height: 12px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="12" style="height: 12px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>

							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 36px; padding-right: 36px;"
										    valign="top" align="left">
											<table class="table-col" align="left" width="273" style="padding-right: 18px; table-layout: fixed;" cellspacing="0" cellpadding="0"
											    border="0">
												<tbody>
													<tr>
														<td class="table-col-td" width="255" align="center" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; text-align: center;"
														    valign="top">
															<img src="/templates/ace/assets/images/placeholder/255x150.png" style="border: 0px none #444444; vertical-align: middle; display: block; padding-bottom: 9px;"
															    hspace="0" vspace="0" border="0">
														</td>
													</tr>
												</tbody>
											</table>

											<table class="table-col" align="left" width="255" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="255" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<table class="header-row" width="255" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
																<tbody>
																	<tr>
																		<td class="header-row-td" width="255" style="font-family: Arial, sans-serif; font-weight: normal; line-height: 19px; color: #6397bf; margin: 0px; font-size: 17px; padding-bottom: 8px; padding-top: 0px;"
																		    valign="top" align="left">Two column - text below</td>
																	</tr>
																</tbody>
															</table>
															HELLO
															<br>
															<br>
															<br>
															<br>
															<div style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; text-align: right;">
																<a href="#" style="color: #ffffff; text-decoration: none; margin: 0px; text-align: center; vertical-align: baseline; border: 4px solid #6fb3e0; padding: 4px 9px; font-size: 15px; line-height: 21px; background-color: #6fb3e0;">
																	Read More &raquo;
																</a>
															</div>
														</td>
													</tr>
												</tbody>
											</table>

										</td>
									</tr>
								</tbody>
							</table>

							<table class="table-space" height="8" style="height: 8px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="8" style="height: 8px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="24" style="height: 24px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="24" style="height: 24px; width: 600px; padding-left: 18px; padding-right: 18px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="center">&nbsp;
											<table bgcolor="#E8E8E8" height="0" width="100%" cellspacing="0" cellpadding="0" border="0">
												<tbody>
													<tr>
														<td bgcolor="#E8E8E8" height="1" width="100%" style="height: 1px; font-size:0;" valign="top" align="left">&nbsp;</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>

							<div style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px;">
								<table class="table-row" style="table-layout: auto; padding-right: 24px; padding-left: 24px; width: 600px; background-color: #ffffff;"
								    bgcolor="#FFFFFF" width="600" cellspacing="0" cellpadding="0" border="0">
									<tbody>
										<tr style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px;">
											<td class="table-row-td" style="padding-right: 16px; padding-bottom: 12px; font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
											    valign="top" align="left">
												<span style="font-family: Arial, sans-serif; line-height: 19px; color: #478fca; font-size: 13px; font-weight: bold;">Wednesday</span>
												<br> 19/11/2013
											</td>
											<td class="table-row-td" style="padding-bottom: 12px; font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
											    valign="top" align="left">
												<b>Convallis eget nisi mauris a sagittis dui </b>
												<br> Fusce sit amet libero sit amet erat venenatis sollicitudin vitae &hellip;
											</td>
										</tr>
										<tr style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px;">
											<td class="table-row-td" style="padding-right: 16px; font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
											    valign="top" align="left">
												<span style="font-family: Arial, sans-serif; line-height: 19px; color: #478fca; font-size: 13px; font-weight: bold;">Monday</span>
												<br> 02/02/2014
											</td>
											<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
											    valign="top" align="left">
												<b>Pellentesque sem dolor, fringilla et pharetra vitae</b>
												<br> Sed iaculis pulvinar ligula, ornare fringilla ante viverra et &hellip;
											</td>
										</tr>
									</tbody>
								</table>


							</div>



							<table class="table-space" height="12" style="height: 12px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="12" style="height: 12px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="24" style="height: 24px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="24" style="height: 24px; width: 600px; padding-left: 18px; padding-right: 18px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="center">&nbsp;
											<table bgcolor="#E8E8E8" height="0" width="100%" cellspacing="0" cellpadding="0" border="0">
												<tbody>
													<tr>
														<td bgcolor="#E8E8E8" height="1" width="100%" style="height: 1px; font-size:0;" valign="top" align="left">&nbsp;</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>



							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 36px; padding-right: 36px;"
										    valign="top" align="left">
											<table class="table-col" align="left" width="273" style="padding-right: 18px; table-layout: fixed;" cellspacing="0" cellpadding="0"
											    border="0">
												<tbody>
													<tr>
														<td class="table-col-td" width="255" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<table class="header-row" width="255" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
																<tbody>
																	<tr>
																		<td class="header-row-td" width="255" style="font-family: Arial, sans-serif; font-weight: normal; line-height: 19px; color: #478fca; margin: 0px; font-size: 18px; padding-bottom: 8px; padding-top: 10px;"
																		    valign="top" align="left">Our Social Channels</td>
																	</tr>
																</tbody>
															</table>

															<div style="font-family: Arial, sans-serif; line-height: 36px; color: #444444; font-size: 13px;">
																<a href="#" style="color: #ffffff; text-decoration: none; margin: 0px; text-align: center; vertical-align: baseline; border: 4px solid #6fb3e0; padding: 4px 9px; font-size: 14px; line-height: 19px; background-color: #6fb3e0;">Twitter</a>
																<a href="#" style="color: #6688a6; text-decoration: none; margin: 0px; text-align: center; vertical-align: baseline; border-width: 1px 1px 2px; border-style: solid; border-color: #8aafce; padding: 6px 12px; font-size: 14px; line-height: 20px; background-color: #ffffff;">Facebook</a>
																<a href="#" style="color: #b7837a; text-decoration: none; margin: 0px; text-align: center; vertical-align: baseline; border-width: 1px 1px 2px; border-style: solid; border-color: #d7a59d; padding: 6px 12px; font-size: 14px; line-height: 20px; background-color: #ffffff;">Google+</a>
															</div>
														</td>
													</tr>
												</tbody>
											</table>

											<table class="table-col" align="left" width="255" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="255" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<table class="header-row" width="255" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
																<tbody>
																	<tr>
																		<td class="header-row-td" width="255" style="font-family: Arial, sans-serif; font-weight: normal; line-height: 19px; color: #478fca; margin: 0px; font-size: 18px; padding-bottom: 8px; padding-top: 10px;"
																		    valign="top" align="left">Our Contact Info</td>
																	</tr>
																</tbody>
															</table>
															Phone: 408.341.0600
															<br> Email: hseldon@trantor.com
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="16" style="height: 16px; font-size: 0px; line-height: 0; width: 600px; background-color: #ffffff;"
							    width="600" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="16" style="height: 16px; width: 600px; background-color: #ffffff;"
										    width="600" bgcolor="#FFFFFF" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>


							<table class="table-space" height="6" style="height: 6px; font-size: 0px; line-height: 0; width: 600px; background-color: #e4e6e9;"
							    width="600" bgcolor="#E4E6E9" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="6" style="height: 6px; width: 600px; background-color: #e4e6e9;"
										    width="600" bgcolor="#E4E6E9" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
							<table class="table-row" width="600" bgcolor="#FFFFFF" style="table-layout: fixed; background-color: #ffffff;" cellspacing="0"
							    cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-row-td" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal; padding-left: 36px; padding-right: 36px;"
										    valign="top" align="left">
											<table class="table-col" align="left" width="528" cellspacing="0" cellpadding="0" border="0" style="table-layout: fixed;">
												<tbody>
													<tr>
														<td class="table-col-td" width="528" style="font-family: Arial, sans-serif; line-height: 19px; color: #444444; font-size: 13px; font-weight: normal;"
														    valign="top" align="left">
															<table class="table-space" height="16" style="height: 16px; font-size: 0px; line-height: 0; width: 528px; background-color: #ffffff;"
															    width="528" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
																<tbody>
																	<tr>
																		<td class="table-space-td" valign="middle" height="16" style="height: 16px; width: 528px; background-color: #ffffff;"
																		    width="528" bgcolor="#FFFFFF" align="left">&nbsp;</td>
																	</tr>
																</tbody>
															</table>
															<div style="font-family: Arial, sans-serif; line-height: 19px; color: #777777; font-size: 14px; text-align: center;">&copy; 2014 by Ace Company</div>
															<table class="table-space" height="12" style="height: 12px; font-size: 0px; line-height: 0; width: 528px; background-color: #ffffff;"
															    width="528" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
																<tbody>
																	<tr>
																		<td class="table-space-td" valign="middle" height="12" style="height: 12px; width: 528px; background-color: #ffffff;"
																		    width="528" bgcolor="#FFFFFF" align="left">&nbsp;</td>
																	</tr>
																</tbody>
															</table>
															<div style="font-family: Arial, sans-serif; line-height: 19px; color: #bbbbbb; font-size: 13px; text-align: center;">
																<a href="#" style="color: #428bca; text-decoration: none; background-color: transparent;">Terms</a>
																&nbsp;|&nbsp;
																<a href="#" style="color: #428bca; text-decoration: none; background-color: transparent;">Privacy</a>
																&nbsp;|&nbsp;
																<a href="#" style="color: #428bca; text-decoration: none; background-color: transparent;">Unsubscribe</a>
															</div>
															<table class="table-space" height="16" style="height: 16px; font-size: 0px; line-height: 0; width: 528px; background-color: #ffffff;"
															    width="528" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" border="0">
																<tbody>
																	<tr>
																		<td class="table-space-td" valign="middle" height="16" style="height: 16px; width: 528px; background-color: #ffffff;"
																		    width="528" bgcolor="#FFFFFF" align="left">&nbsp;</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr>
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>
							<table class="table-space" height="8" style="height: 8px; font-size: 0px; line-height: 0; width: 600px; background-color: #e4e6e9;"
							    width="600" bgcolor="#E4E6E9" cellspacing="0" cellpadding="0" border="0">
								<tbody>
									<tr>
										<td class="table-space-td" valign="middle" height="8" style="height: 8px; width: 600px; background-color: #e4e6e9;"
										    width="600" bgcolor="#E4E6E9" align="left">&nbsp;</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>

</html>
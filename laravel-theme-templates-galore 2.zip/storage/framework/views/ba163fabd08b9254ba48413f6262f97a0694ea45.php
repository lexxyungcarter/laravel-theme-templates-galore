<div class="page-header">
    <h1>
        <?php echo e($page); ?>

        <small>
            <i class="ace-icon fa fa-angle-double-right"></i>
            <?php echo e(isset($page_desc) ? $page_desc : ''); ?>

        </small>
    </h1>
</div>
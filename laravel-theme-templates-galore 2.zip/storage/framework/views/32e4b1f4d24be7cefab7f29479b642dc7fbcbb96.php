<footer class="footer">
    <div class="container">
        <nav>
            <ul>
                <li><a href="#" target="_blank">Contact Us</a></li>
                <li><a href="#" target="_blank">About Us</a></li>
                <li><a href="javascript:void(0);">FAQ</a></li>
            </ul>
        </nav>
        <div class="copyright">
            ©
            <script>
                document.write(new Date().getFullYear())
            </script>
            <span>Designed by <a href="#" target="_blank">Lexx</a></span>
        </div>
    </div>
</footer>
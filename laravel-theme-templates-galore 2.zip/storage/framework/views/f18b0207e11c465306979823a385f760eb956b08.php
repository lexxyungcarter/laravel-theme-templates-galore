<!DOCTYPE html>
<html class="no-js chrome" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="description" content="Responsive Bootstrap 4 and web Application ui kit.">
    <title><?php echo e(isset($title) ? $title : ''); ?> | <?php echo e($site_name); ?></title>

    
    <link rel="stylesheet" href="/templates/dashy/assets/css/bootstrap.min.css">
    
    
    
    
    <?php echo $__env->yieldContent('pre-styles'); ?>

    <!-- Custom Css -->
    <link rel="stylesheet" href="/templates/dashy/assets/css/main.css">
    <link rel="stylesheet" href="/templates/dashy/assets/css/authentication.css">
    <link rel="stylesheet" href="/templates/dashy/assets/css/color_skins.css">
    
    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body class="theme-purple authentication sidebar-collapse">
    
    <?php echo $__env->make('templates.dashy.layouts.partials.auth-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <!-- Main Content -->
    <div class="page-header">
        <div class="page-header-image" style="background-image:url(/templates/dashy/assets/img/login.jpg)"></div>
        <div class="container">
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        
        <?php echo $__env->make('templates.dashy.layouts.partials.auth-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
    </div>

    
    
    <?php echo e(Html::script('/js/jquery-3.2.1.min.js')); ?>

    
    <?php echo e(Html::script('/bootstrap4/js/bootstrap.min.js')); ?>

    
    <?php echo e(Html::script('/templates/dashy/assets/js/jquery.slimscroll.min.js')); ?>

    
    <?php echo e(Html::script('/templates/dashy/assets/js/screenfull.min.js')); ?>

    
    
    <?php echo e(Html::script('/templates/dashy/assets/js/waves.min.js')); ?>


    
    <?php echo $__env->yieldContent('pre-scripts'); ?>

    
    <?php echo $__env->yieldContent('scripts'); ?>

    </body>

</html>
<!DOCTYPE html>
<html class="no-js chrome" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="description" content="Responsive Bootstrap 4 and web Application ui kit.">
    <title><?php echo e(isset($title) ? $title : ''); ?> | <?php echo e($site_name); ?></title>

    
    <link rel="stylesheet" href="/templates/dashy/assets/css/bootstrap.min.css">
    
    
    
    
    <?php echo $__env->yieldContent('pre-styles'); ?>

    <!-- Custom Css -->
    <link rel="stylesheet" href="/templates/dashy/assets/css/main.css">
    
    <?php echo $__env->yieldContent('styles'); ?>
    
    <link rel="stylesheet" href="/templates/dashy/assets/css/color_skins.css">

</head>

<body class="theme-purple <?php echo $__env->yieldContent('body-class'); ?>">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="zmdi-hc-spin" src="/templates/dashy/assets/img/logo.svg" width="48" height="48" alt="Oreo">
            </div>
            <p>Please wait...</p>
        </div>
    </div>

    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>

    
    <?php echo $__env->make('templates.dashy.layouts.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    <?php echo $__env->yieldContent('sidebar'); ?>
    
    
    <?php echo $__env->make('templates.dashy.layouts.partials.right-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    <?php echo $__env->make('templates.dashy.layouts.partials.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <!-- Main Content -->
    <section class="content <?php echo $__env->yieldContent('page-class'); ?>">
        
        <?php echo $__env->make('templates.dashy.layouts.partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="container-fluid">
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </section>

    
    
    <?php echo e(Html::script('/js/jquery-3.2.1.min.js')); ?>

    
    <?php echo e(Html::script('/bootstrap4/js/bootstrap.min.js')); ?>

    
    <?php echo e(Html::script('/templates/dashy/assets/js/jquery.slimscroll.min.js')); ?>

    
    <?php echo e(Html::script('/templates/dashy/assets/js/screenfull.min.js')); ?>

    
    
    <?php echo e(Html::script('/templates/dashy/assets/js/waves.min.js')); ?>


    
    <?php echo $__env->yieldContent('pre-scripts'); ?>

    
    <script src="/templates/dashy/assets/js/main.js"></script>

    
    <?php echo $__env->make('layouts.partials.tracking', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->yieldContent('scripts'); ?>

    </body>

</html>
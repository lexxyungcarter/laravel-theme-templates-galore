<?php $__env->startSection('pre-styles'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pre-scripts'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-class'); ?>
    home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Blank Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-description'); ?>
    A blank page to start your development
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-breadcrumbs'); ?>
    <li class="breadcrumb-item"><a href="javascript:void(0);">Sample Pages</a></li>
    <li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row clearfix">
        <div class="col-lg-12">
            <div class="card">
                <div class="body">
                    <h4>Stater page</h4>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.' . $theme . '.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>